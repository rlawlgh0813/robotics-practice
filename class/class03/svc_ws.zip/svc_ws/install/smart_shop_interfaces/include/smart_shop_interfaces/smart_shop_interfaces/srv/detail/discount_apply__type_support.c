// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from smart_shop_interfaces:srv/DiscountApply.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "smart_shop_interfaces/srv/detail/discount_apply__rosidl_typesupport_introspection_c.h"
#include "smart_shop_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "smart_shop_interfaces/srv/detail/discount_apply__functions.h"
#include "smart_shop_interfaces/srv/detail/discount_apply__struct.h"


// Include directives for member types
// Member `item_id`
#include "rosidl_runtime_c/string_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void smart_shop_interfaces__srv__DiscountApply_Request__rosidl_typesupport_introspection_c__DiscountApply_Request_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  smart_shop_interfaces__srv__DiscountApply_Request__init(message_memory);
}

void smart_shop_interfaces__srv__DiscountApply_Request__rosidl_typesupport_introspection_c__DiscountApply_Request_fini_function(void * message_memory)
{
  smart_shop_interfaces__srv__DiscountApply_Request__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember smart_shop_interfaces__srv__DiscountApply_Request__rosidl_typesupport_introspection_c__DiscountApply_Request_message_member_array[2] = {
  {
    "item_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(smart_shop_interfaces__srv__DiscountApply_Request, item_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "original_amount",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(smart_shop_interfaces__srv__DiscountApply_Request, original_amount),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers smart_shop_interfaces__srv__DiscountApply_Request__rosidl_typesupport_introspection_c__DiscountApply_Request_message_members = {
  "smart_shop_interfaces__srv",  // message namespace
  "DiscountApply_Request",  // message name
  2,  // number of fields
  sizeof(smart_shop_interfaces__srv__DiscountApply_Request),
  smart_shop_interfaces__srv__DiscountApply_Request__rosidl_typesupport_introspection_c__DiscountApply_Request_message_member_array,  // message members
  smart_shop_interfaces__srv__DiscountApply_Request__rosidl_typesupport_introspection_c__DiscountApply_Request_init_function,  // function to initialize message memory (memory has to be allocated)
  smart_shop_interfaces__srv__DiscountApply_Request__rosidl_typesupport_introspection_c__DiscountApply_Request_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t smart_shop_interfaces__srv__DiscountApply_Request__rosidl_typesupport_introspection_c__DiscountApply_Request_message_type_support_handle = {
  0,
  &smart_shop_interfaces__srv__DiscountApply_Request__rosidl_typesupport_introspection_c__DiscountApply_Request_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_smart_shop_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, smart_shop_interfaces, srv, DiscountApply_Request)() {
  if (!smart_shop_interfaces__srv__DiscountApply_Request__rosidl_typesupport_introspection_c__DiscountApply_Request_message_type_support_handle.typesupport_identifier) {
    smart_shop_interfaces__srv__DiscountApply_Request__rosidl_typesupport_introspection_c__DiscountApply_Request_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &smart_shop_interfaces__srv__DiscountApply_Request__rosidl_typesupport_introspection_c__DiscountApply_Request_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "smart_shop_interfaces/srv/detail/discount_apply__rosidl_typesupport_introspection_c.h"
// already included above
// #include "smart_shop_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "smart_shop_interfaces/srv/detail/discount_apply__functions.h"
// already included above
// #include "smart_shop_interfaces/srv/detail/discount_apply__struct.h"


// Include directives for member types
// Member `reason`
// already included above
// #include "rosidl_runtime_c/string_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void smart_shop_interfaces__srv__DiscountApply_Response__rosidl_typesupport_introspection_c__DiscountApply_Response_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  smart_shop_interfaces__srv__DiscountApply_Response__init(message_memory);
}

void smart_shop_interfaces__srv__DiscountApply_Response__rosidl_typesupport_introspection_c__DiscountApply_Response_fini_function(void * message_memory)
{
  smart_shop_interfaces__srv__DiscountApply_Response__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember smart_shop_interfaces__srv__DiscountApply_Response__rosidl_typesupport_introspection_c__DiscountApply_Response_message_member_array[3] = {
  {
    "discounted_amount",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(smart_shop_interfaces__srv__DiscountApply_Response, discounted_amount),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "discount_rate",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(smart_shop_interfaces__srv__DiscountApply_Response, discount_rate),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reason",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(smart_shop_interfaces__srv__DiscountApply_Response, reason),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers smart_shop_interfaces__srv__DiscountApply_Response__rosidl_typesupport_introspection_c__DiscountApply_Response_message_members = {
  "smart_shop_interfaces__srv",  // message namespace
  "DiscountApply_Response",  // message name
  3,  // number of fields
  sizeof(smart_shop_interfaces__srv__DiscountApply_Response),
  smart_shop_interfaces__srv__DiscountApply_Response__rosidl_typesupport_introspection_c__DiscountApply_Response_message_member_array,  // message members
  smart_shop_interfaces__srv__DiscountApply_Response__rosidl_typesupport_introspection_c__DiscountApply_Response_init_function,  // function to initialize message memory (memory has to be allocated)
  smart_shop_interfaces__srv__DiscountApply_Response__rosidl_typesupport_introspection_c__DiscountApply_Response_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t smart_shop_interfaces__srv__DiscountApply_Response__rosidl_typesupport_introspection_c__DiscountApply_Response_message_type_support_handle = {
  0,
  &smart_shop_interfaces__srv__DiscountApply_Response__rosidl_typesupport_introspection_c__DiscountApply_Response_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_smart_shop_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, smart_shop_interfaces, srv, DiscountApply_Response)() {
  if (!smart_shop_interfaces__srv__DiscountApply_Response__rosidl_typesupport_introspection_c__DiscountApply_Response_message_type_support_handle.typesupport_identifier) {
    smart_shop_interfaces__srv__DiscountApply_Response__rosidl_typesupport_introspection_c__DiscountApply_Response_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &smart_shop_interfaces__srv__DiscountApply_Response__rosidl_typesupport_introspection_c__DiscountApply_Response_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "smart_shop_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "smart_shop_interfaces/srv/detail/discount_apply__rosidl_typesupport_introspection_c.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/service_introspection.h"

// this is intentionally not const to allow initialization later to prevent an initialization race
static rosidl_typesupport_introspection_c__ServiceMembers smart_shop_interfaces__srv__detail__discount_apply__rosidl_typesupport_introspection_c__DiscountApply_service_members = {
  "smart_shop_interfaces__srv",  // service namespace
  "DiscountApply",  // service name
  // these two fields are initialized below on the first access
  NULL,  // request message
  // smart_shop_interfaces__srv__detail__discount_apply__rosidl_typesupport_introspection_c__DiscountApply_Request_message_type_support_handle,
  NULL  // response message
  // smart_shop_interfaces__srv__detail__discount_apply__rosidl_typesupport_introspection_c__DiscountApply_Response_message_type_support_handle
};

static rosidl_service_type_support_t smart_shop_interfaces__srv__detail__discount_apply__rosidl_typesupport_introspection_c__DiscountApply_service_type_support_handle = {
  0,
  &smart_shop_interfaces__srv__detail__discount_apply__rosidl_typesupport_introspection_c__DiscountApply_service_members,
  get_service_typesupport_handle_function,
};

// Forward declaration of request/response type support functions
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, smart_shop_interfaces, srv, DiscountApply_Request)();

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, smart_shop_interfaces, srv, DiscountApply_Response)();

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_smart_shop_interfaces
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_introspection_c, smart_shop_interfaces, srv, DiscountApply)() {
  if (!smart_shop_interfaces__srv__detail__discount_apply__rosidl_typesupport_introspection_c__DiscountApply_service_type_support_handle.typesupport_identifier) {
    smart_shop_interfaces__srv__detail__discount_apply__rosidl_typesupport_introspection_c__DiscountApply_service_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  rosidl_typesupport_introspection_c__ServiceMembers * service_members =
    (rosidl_typesupport_introspection_c__ServiceMembers *)smart_shop_interfaces__srv__detail__discount_apply__rosidl_typesupport_introspection_c__DiscountApply_service_type_support_handle.data;

  if (!service_members->request_members_) {
    service_members->request_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, smart_shop_interfaces, srv, DiscountApply_Request)()->data;
  }
  if (!service_members->response_members_) {
    service_members->response_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, smart_shop_interfaces, srv, DiscountApply_Response)()->data;
  }

  return &smart_shop_interfaces__srv__detail__discount_apply__rosidl_typesupport_introspection_c__DiscountApply_service_type_support_handle;
}

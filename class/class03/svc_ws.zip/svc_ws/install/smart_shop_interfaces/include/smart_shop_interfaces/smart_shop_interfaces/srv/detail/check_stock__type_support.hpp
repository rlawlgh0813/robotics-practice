// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from smart_shop_interfaces:srv/CheckStock.idl
// generated code does not contain a copyright notice

#ifndef SMART_SHOP_INTERFACES__SRV__DETAIL__CHECK_STOCK__TYPE_SUPPORT_HPP_
#define SMART_SHOP_INTERFACES__SRV__DETAIL__CHECK_STOCK__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "smart_shop_interfaces/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/service_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_smart_shop_interfaces
const rosidl_service_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  smart_shop_interfaces,
  srv,
  CheckStock
)();
#ifdef __cplusplus
}
#endif

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_smart_shop_interfaces
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  smart_shop_interfaces,
  srv,
  CheckStock_Request
)();
#ifdef __cplusplus
}
#endif

// already included above
// #include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_smart_shop_interfaces
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  smart_shop_interfaces,
  srv,
  CheckStock_Response
)();
#ifdef __cplusplus
}
#endif


#endif  // SMART_SHOP_INTERFACES__SRV__DETAIL__CHECK_STOCK__TYPE_SUPPORT_HPP_
